2022_final.ipynb and 2023_final.ipynb -> merging of data gouv csv for each year
aggregation_final.ipynb -> concatenate the results of 2023 and 2022
pretraitement_final.ipynb -> pretraitement(outliers,categorial) of the agregation 2023 2022
pretraitement_meteo.ipynb -> for weather
model_avec_meteo.ipynb -> tout les modeles entrainer avec la meteo
model_sans_meteo.ipynb -> tout les modeles entrainer sans la meteo
doc2-> documentation variables